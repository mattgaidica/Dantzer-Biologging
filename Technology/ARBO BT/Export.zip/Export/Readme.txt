FR4, 1.6mm (0.062") thickness
1oz weight (or default/standard for copper)
Soldermask two-sided preferred, but whatever is cheapest, don't need both
4 layers
1.6mm thickness
.076mm (3mil) min trace
0.45/0.2mm through via
0.28/0.15mm blind/buried via